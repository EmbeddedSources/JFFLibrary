#import "JFFAlertButtonAction.h"

#import <Foundation/Foundation.h>

@interface JFFAlertButton : NSObject

@property ( nonatomic, strong ) NSString* title;
@property ( nonatomic, copy ) JFFAlertButtonAction action;

+(id)alertButton:( NSString* )title_ action:( JFFAlertButtonAction )action_;

@end
