typedef void (^JFFAlertButtonAction)( id sender_ );
