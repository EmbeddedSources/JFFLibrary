#import "JFFAlertView.h"

#import "JFFAlertButton.h"
#import "NSObject+JFFAlertButton.h"

#import "JFFAlertViewQueue.h"

#define UI_APPLICATION_DID_ENTER_BACKGROUND_NOTIFICATION @"UIApplicationDidEnterBackgroundNotification"

@interface JFFAlertView () < UIAlertViewDelegate >

@property ( nonatomic, strong ) UIAlertView* alertView;
@property ( nonatomic, strong ) NSMutableArray* alertButtons;

-(void)forceShow;

@end

@implementation JFFAlertView

@synthesize alertView;
@synthesize dismissBeforeEnterBackground;
@synthesize alertButtons;
@synthesize didPresentHandler;

-(void)dealloc
{
   self.alertView.delegate = nil;
   [ [ NSNotificationCenter defaultCenter ] removeObserver: self ];
}

-(void)dismissWithClickedButtonIndex:( NSInteger )buttonIndex_ animated:( BOOL )animated_
{
   [ self.alertView dismissWithClickedButtonIndex: buttonIndex_ animated: NO ];
   [ self alertView: self.alertView didDismissWithButtonIndex: buttonIndex_ ];
}

-(void)forceDismiss
{
   [ self dismissWithClickedButtonIndex: [ self.alertView cancelButtonIndex ] animated: NO ];
   [ self dismissWithClickedButtonIndex: [ self.alertView cancelButtonIndex ] animated: NO ];
}

+(void)dismissAllAlertViews
{
   [ [ JFFAlertViewQueue sharedQueue ] dismissAll ];
}

+(void)showAlertWithTitle:( NSString* )title_
              description:( NSString* )description_
{
   JFFAlertView* alert_ = [ JFFAlertView alertWithTitle: title_
                                                message: description_
                                      cancelButtonTitle: NSLocalizedString( @"OK", nil )
                                      otherButtonTitles: nil ];

   [ alert_ show ];
}

+(void)showErrorWithDescription:( NSString* )description_
{
   [ self showAlertWithTitle: NSLocalizedString( @"ERROR", nil ) description: description_ ];
}

+(void)showInformationWithDescription:( NSString* )description_
{
   [ self showAlertWithTitle: NSLocalizedString( @"INFORMATION", nil ) description: description_ ];
}

-(id)initWithTitle:( NSString* )title_
           message:( NSString* )message_
 cancelButtonTitle:( NSString* )cancel_button_title_
otherButtonTitlesArray:( NSArray* )other_button_titles_
{
   self = [ super init ];
   if ( !self )
      return nil;

   self.dismissBeforeEnterBackground = YES;

   self.alertView = [ [ UIAlertView alloc ] initWithTitle: title_
                                                  message: message_ 
                                                 delegate: self
                                        cancelButtonTitle: cancel_button_title_
                                        otherButtonTitles: nil, nil ];

   for ( NSString* button_title_ in other_button_titles_ )
   {
      [ self.alertView addButtonWithTitle: button_title_ ];
   }

   [ [ NSNotificationCenter defaultCenter] addObserver: self
                                              selector: @selector( applicationDidEnterBackground: )
                                                  name: UI_APPLICATION_DID_ENTER_BACKGROUND_NOTIFICATION 
                                                object: nil ];

   return self;
}

-(NSInteger)addAlertButtonWithIndex:( id )button_
{
   JFFAlertButton* alert_button_ = [ alert_button_ toAlertButton ];
   NSInteger index_ = [ self.alertView addButtonWithTitle: alert_button_.title ];
   [ self.alertButtons insertObject: alert_button_ atIndex: index_ ];
   return index_;
}

-(void)addAlertButton:( id )button_
{
   [ self addAlertButtonWithIndex: button_ ];
}

-(void)addAlertButtonWithTitle:( NSString* )title_ action:( JFFAlertButtonAction )action_
{
   [ self addAlertButton: [ JFFAlertButton alertButton: title_ action: action_ ] ];
}

-(NSInteger)addButtonWithTitle:( NSString* )title_
{
   return [ self addAlertButtonWithIndex: title_ ];
}

+(id)alertWithTitle:( NSString* )title_
            message:( NSString* )message_
  cancelButtonTitle:( id )cancel_button_title_
  otherButtonTitles:( id )other_button_titles_, ...
{
   [ NSThread assertMainThread ];

   NSMutableArray* other_alert_buttons_ = [ NSMutableArray array ];
   NSMutableArray* other_alert_string_titles_ = [ NSMutableArray array ];

   va_list args;
   va_start( args, other_button_titles_ );
   for ( NSString* button_title_ = other_button_titles_; button_title_ != nil; button_title_ = va_arg( args, NSString* ) )
   {
      JFFAlertButton* alert_button_ = [ button_title_ toAlertButton ];
      [ other_alert_buttons_ addObject: alert_button_ ];
      [ other_alert_string_titles_ addObject: alert_button_.title ];
   }
   va_end( args );

   JFFAlertButton* cancel_button_ = [ cancel_button_title_ toAlertButton ];
   if ( cancel_button_ )
   {
      [ other_alert_buttons_ insertObject: cancel_button_ atIndex: 0 ];
   }

   JFFAlertView* alert_view_ = [ [ self alloc ] initWithTitle: title_
                                                       message: message_
                                             cancelButtonTitle: cancel_button_.title
                                        otherButtonTitlesArray: other_alert_string_titles_ ];

   alert_view_.alertButtons = other_alert_buttons_;

   return alert_view_;
}

-(void)show
{
   [ [ JFFAlertViewQueue sharedQueue ] addAlert: self ];

   if ( [ [ JFFAlertViewQueue sharedQueue ] count ] == 1 )
   {
      [ self forceShow ];
   }
}

-(void)applicationDidEnterBackground:( id )sender_
{
   if ( self.dismissBeforeEnterBackground )
   {
      [ self forceDismiss ];
   }
}

-(void)forceShow
{
   [ self.alertView show ];
}

#pragma mark UIAlertViewDelegate

-(void)alertView:( UIAlertView* )alert_view_ clickedButtonAtIndex:( NSInteger )buttonIndex_
{
   JFFAlertButton* alert_button_ = [ self.alertButtons objectAtIndex: buttonIndex_ ];
   if ( alert_button_ )
      alert_button_.action( self );
}

-(void)didPresentAlertView:( UIAlertView* )alertView_
{
   if ( self.didPresentHandler )
      self.didPresentHandler();
}

-(void)alertView:( UIAlertView* )alert_view_ didDismissWithButtonIndex:( NSInteger )buttonIndex_
{
   [ [ JFFAlertViewQueue sharedQueue ] removeAlert: self ];
   [ [ [ JFFAlertViewQueue sharedQueue ] topAlertView ] forceShow ];
}

#pragma mark UIAlertView forwards

-(UIAlertViewStyle)alertViewStyle
{
   return self.alertView.alertViewStyle;
}

-(void)setAlertViewStyle:( UIAlertViewStyle )style_
{
   self.alertView.alertViewStyle = style_;
}

-(UITextField*)textFieldAtIndex:( NSInteger )index_
{
   return [ self.alertView textFieldAtIndex: index_ ];
}
@end
