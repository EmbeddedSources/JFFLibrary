#import "JFFAlertViewQueue.h"

#import "JFFAlertView.h"

@interface JFFAlertViewQueue ()

@property ( nonatomic, strong ) NSMutableArray* queue;

@end

@implementation JFFAlertViewQueue

@synthesize queue = _queue;

+(JFFAlertViewQueue*)sharedQueue
{
   static JFFAlertViewQueue* queue_ = nil;
   if ( !queue_ )
   {
      queue_ = [ self new ];
   }
   return queue_;
}

-(NSMutableArray*)queue
{
   if ( !_queue )
   {
      _queue = [ [ NSMutableArray alloc ] init ];
   }
   return _queue;
}

-(void)addAlert:( JFFAlertView* )alert_view_
{
   [ self.queue addObject: alert_view_ ];
}

-(void)removeAlert:( JFFAlertView* )alert_view_
{
   [ self.queue removeObject: alert_view_ ];
}

-(void)dismissAll
{
   NSArray* temporary_active_alerts_ = [ [ NSArray alloc ] initWithArray: self.queue ];
   
   for ( JFFAlertView* alert_view_ in temporary_active_alerts_ )
   {
      [ alert_view_ forceDismiss ];
   }
}

-(JFFAlertView*)topAlertView
{
   if ( [ self.queue count ] == 0 )
      return nil;

   return [ self.queue objectAtIndex: 0 ];
}

-(NSUInteger)count
{
   return [ self.queue count ];
}

@end
