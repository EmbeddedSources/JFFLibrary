#import <Foundation/Foundation.h>

@class JFFAlertButton;

@interface NSObject (JFFAlertButton)

-(JFFAlertButton*)toAlertButton;

@end
