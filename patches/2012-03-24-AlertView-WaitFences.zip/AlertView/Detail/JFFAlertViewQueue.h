#import <UIKit/UIKit.h>

@class JFFAlertView;

@interface JFFAlertViewQueue : NSObject

+(JFFAlertViewQueue*)sharedQueue;

-(void)addAlert:( JFFAlertView* )alert_view_;
-(void)removeAlert:( JFFAlertView* )alert_view_;
-(void)dismissAll;

-(JFFAlertView*)topAlertView;

-(NSUInteger)count;

@end
